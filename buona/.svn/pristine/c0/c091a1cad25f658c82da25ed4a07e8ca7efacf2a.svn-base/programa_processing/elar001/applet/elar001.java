import processing.core.*; 
import processing.xml.*; 

import de.bezier.data.sql.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class elar001 extends PApplet {

/*
v001

eLAR

A Bdunk & Wireless Galicia \u00b4s Project

-- Free Domotic Sistem --

*/

//data base SQL

//
PFont font;

MySQL msql;

Button b_en, b_es, b_gl;

Button[] panel;

boolean[] bos_panel;

int width_default=800;
int height_default=600;

//colors zone
int white_color = color(255, 255, 255);
int yellow_color = color(242, 204, 47);
int black_color = color(0,0,0);
int red_color_01 = color(255,0,125);
int red_color_02 = color(255,0,0);
int green_color = color(125,255,0);
int blue_color = color (0,0, 255);

//color button
int button_gray_color=color(204);
int button_on_gray_color=color(255);
int button_press_gray_color=color(0);

//size button
int button_width=135;
int button_height=35;
int button_width_min=38;
int button_height_min=button_height;

//init button positions
int button_x=10;
int button_y=60;
int button_separation=10;
int button_x_min=20;
int button_reviser=6;
int button_x_lang=width_default-150;
int button_y_lang=4;
int button_lang_separation=5;
int button_lang_adjustment=0;

//que bot\u00f3n est\u00e1 seleccionado?
boolean bos_en=false;
boolean bos_es=false;
boolean bos_gl=false;
boolean bos_home=false;
boolean bos_about_us=true;
boolean bos_services=false;
boolean bos_proyects=false;
boolean bos_contact=false;

//english
int lang = 0;

//welcome to home :-)
int section=0;

//other vars
int y = year(); //the year
int panel_number;

public void setup() {
  
  //mysql configuration  
   String user     = "elar";
   String pass     = "elar";
   String database = "elar";
   String server = "192.168.1.121";

  msql = new MySQL( this, server, database, user, pass );
  msql.connect() ;
  
  if ( msql.connect() )
    {
        //CONFIGURATION
        msql.query( "SELECT * FROM configuration" );
        msql.next();
        
        width_default=msql.getInt( "screen_width" );
        height_default=msql.getInt( "screen_height" );
        println("width_default: "+width_default);
        println("height_default: "+height_default);
    } 
 
   size(width_default,height_default);
   
   //this looks better
   smooth();
   
   font=loadFont("Consolas-48.vlw"); 
}


public void draw() {
 
  background(yellow_color);
  fill(white_color);
  textFont(font);
  
  //header
  fill(0);
  stroke(0);
  rect(0,0,width_default,50);
  textSize(30);
  fill(white_color);
  text(l_page_title[lang],10,33); 
  
  //slogan
  textSize(18);
  text("["+l_slogan[lang]+"]", 250, 30); 
  
  //the footer
  fill(black_color);
  textSize(11);
  text(l_footer[lang]+" "+y, 10,height_default-20);
  
  //lang buttons
  textSize(18);
  
  buttonsOn();
  
  b_en = new Button(button_x_lang, button_y_lang+1*(button_lang_separation), button_width_min, button_height_min, button_gray_color, button_on_gray_color, button_press_gray_color, "EN", bos_en, button_lang_adjustment);
  b_gl = new Button(button_x_lang+1*(button_lang_separation+button_width_min), button_y_lang+1*(button_lang_separation), button_width_min, button_height_min, button_gray_color, button_on_gray_color, button_press_gray_color, "GL", bos_gl, button_lang_adjustment);
  b_es = new Button(button_x_lang+2*(button_lang_separation+button_width_min), button_y_lang+1*(button_lang_separation), button_width_min, button_height_min, button_gray_color, button_on_gray_color, button_press_gray_color, "ES", bos_es, button_lang_adjustment);
  
   if ( msql.connect() )
    {
        //CONFIGURATION
        msql.query( " SELECT COUNT( * ) AS panel_number FROM panel " );
        msql.next();
        
        //number of panels
        panel_number=msql.getInt("panel_number");
        panel_number++;
        println("panel_number: "+panel_number);

   } 
   panel = new Button[panel_number];
   
   bos_panel = new boolean[panel_number];
   
   
   for (int i = 0; i < panel.length; i++) {
     bos_panel[i]=false; 
   }
   
   
   
   switch (section) { 
     case 0: //about us
      show_about_us();
      int last_number=panel.length-1;
      bos_panel[last_number]=true;
     break;
    }
    
    numberPanels();
  
  initButtons();
  
}

public void mousePressed() { 
  if (b_en.press() == true) { lang = 0; } 
  if (b_gl.press() == true) { lang = 1; }
  if (b_es.press() == true) { lang = 2; }
  for (int i = 0; i < panel.length; i++) {
    if (panel[i].press() == true) { section = i; }
  }
} 

public void mouseReleased() { 
  b_en.release();
  b_es.release();
  b_gl.release();
  for (int i = 0; i < panel.length; i++) {
    panel[i].release(); 
  }


}

public void initButtons() {
  b_en.update();
  b_es.update();
  b_gl.update();
  b_en.display();
  b_es.display();
  b_gl.display();
  for (int i = 0; i < panel.length; i++) {
    panel[i].update(); 
    panel[i].display();
  }
}

public void buttonsOn() {
   switch (lang) { 
     case 0:
      bos_en=true;
      bos_es=false;
      bos_gl=false;
     break;
     case 1:
      bos_en=false;
      bos_es=false;
      bos_gl=true;
     break;
     case 2:
      bos_en=false;
      bos_es=true;
      bos_gl=false;
     break;
   }
   
 }


public int numberPanels () {
   if ( msql.connect() )
    {
        //CONFIGURATION
        msql.query( "SELECT * FROM panel" );
               
        int i=0;        
        while (msql.next()) {
          
          int id_panel=msql.getInt( "id_panel" );
          String name=msql.getString( "name") ;
          println("id_panel:"+id_panel);
        
          panel[i] = new Button(button_x, button_y+i*(button_separation+button_height), button_width, button_height, button_gray_color, button_on_gray_color, button_press_gray_color, name, bos_panel[i], button_reviser);
          i++;
       
      }
        
       panel[i] = new Button(button_x, button_y+i*(button_separation+button_height), button_width, button_height, button_gray_color, button_on_gray_color, button_press_gray_color, l_about_us[lang], bos_panel[i], button_reviser);
        
       return 1;

   } else {
     
       return 0; 
       
   }
}




//as imaxes
PImage img00, img01;

public void show_about_us() {
  
   textSize(16);
   fill(white_color);

   img00=loadImage("logo_wg.jpg");
   img01=loadImage("logo_bdunk.jpg");

   image(img00, 170, 60, 190, 35);
   image(img01, 170, 120, 175, 75);
 
   text(l_text_about_us[lang], 170, 220); 
    
}
class Button { 
  int x, y; // The x- and y-coordinates 
  int xsize; // Dimension (width) 
  int ysize; // Dimension (width) 
  int baseGray; // Default gray value 
  int overGray; // Value when mouse is over the button 
  int pressGray; // Value when mouse is over and pressed 
  boolean over = false; // True when the mouse is over 
  boolean pressed = false; // True when the mouse is over and pressed 
  String texto_boton;
  boolean on_section;
  int corrector;
  Button(int xp, int yp, int w, int h, int b, int o, int p, String t, boolean os, int corr) { 
    x = xp; 
    y = yp; 
    xsize = w; 
    ysize = h;
    baseGray = b; 
    overGray = o; 
    pressGray = p; 
    texto_boton =t;
    on_section=os;
    corrector=corr;
    
  } 
// Updates the over field every frame 
  public void update() { 
    if ((mouseX >= x) && (mouseX <= x+xsize) && 
        (mouseY >= y) && (mouseY <= y+ysize)) { 
      over = true; 
    } else { 
      over = false; 
    } 
  }
  
  public boolean press() { 
    if (over == true) { 
      pressed = true; 
      return true; 
    } else { 
      return false; 
    } 
  } 
  public void release() { 
    pressed = false; // Set to false when the mouse is released 
  } 
  public void display() { 
    if (pressed == true) { 
      fill(pressGray); 
    } else if (over == true) { 
      fill(overGray); 
    } else { 
      fill(baseGray); 
    } 
    if (on_section == true) {
      fill(overGray);
    }
    stroke(255); 
    rect(x, y, xsize, ysize); 
    fill(0);
    text(texto_boton, x+5, y+(ysize/2)+corrector);
  } 
} 
//l_test={"", "", ""},

String[]
l_page_title={"eLAR Project", "Proxecto eLAR", "Proyecto eLAR"},
l_slogan={"Free Domotic System", "Sistema Dom\u00f3tico Libre", "Sistema Dom\u00f3tico Libre"},
l_footer={
  "eLAR [visit hardprocessing.org] | this panel is make with processing [visit processing.org] | (c) wireless galicia, bdunk",
  "eLAR [visite hardprocessing.org] | este panel est\u00e1 feito con processing [visite processing.org] | (c) wireless galicia, bdunk",
  "eLAR [visite hardprocessing.org] | este panel est\u00e1 hecho con processing [visite processing.org] | (c) wireless galicia, bdunk"
},
l_about_us={"About us", "Sobre n\u00f3s", "Acerca de"},
l_text_about_us={"We are a group of restless minds", "Somos un grupo de mentes inquietas", "Somos un grupo de mentes inquietas"}
;
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "elar001" });
  }
}
